import os
import subprocess
import re
import signal

# Rutas relativas
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WHISPER_BIN = os.path.join(BASE_DIR, "whisper.cpp", "build", "bin", "whisper-cli")
MODELS_DIR = os.path.join(BASE_DIR, "whisper.cpp", "models")
TEMP_WAV = os.path.join(BASE_DIR, "temp_audio.wav")

# Variables globales para controlar el proceso
current_process = None
is_cancelled = False

def get_model_path(model_name):
    mapa_modelos = {
        "Tiny (Muy rápido)": "ggml-tiny.bin",
        "Base (Equilibrado)": "ggml-base.bin",
        "Small (Preciso)": "ggml-small.bin",
        "Medium (Muy preciso)": "ggml-medium.bin",
        "Large (Lento/Pro)": "ggml-large-v3.bin"
    }
    return os.path.join(MODELS_DIR, mapa_modelos.get(model_name, "ggml-base.bin"))

def stop_transcription():
    """Función para matar el proceso desde main.py"""
    global current_process, is_cancelled
    is_cancelled = True
    if current_process:
        print("Deteniendo proceso Whisper...")
        try:
            current_process.kill() # Forzamos la detención
        except:
            pass
        current_process = None

def get_audio_duration(file_path):
    try:
        cmd = ["ffmpeg", "-i", file_path]
        result = subprocess.run(cmd, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True)
        match = re.search(r"Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})", result.stderr)
        if match:
            hours, minutes, seconds = map(float, match.groups())
            return hours * 3600 + minutes * 60 + seconds
    except: pass
    return 0

def convert_to_wav(input_path):
    if os.path.exists(TEMP_WAV): os.remove(TEMP_WAV)
    cmd = ["ffmpeg", "-i", input_path, "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", "-y", TEMP_WAV]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if os.path.exists(TEMP_WAV): return TEMP_WAV
    raise Exception("Error al convertir el audio.")

def run_transcription(input_file, model_selection, callback_text, callback_progress, with_timestamps=False, diarize=False):
    global current_process, is_cancelled

    try:
        is_cancelled = False
        model_path = get_model_path(model_selection)

        if not os.path.exists(model_path):
            callback_text(f"[ERROR] Falta modelo: {os.path.basename(model_path)}\n")
            return

        total_duration = get_audio_duration(input_file)
        wav_path = convert_to_wav(input_file)

        # Construimos el comando base
        cmd = [WHISPER_BIN, "-m", model_path, "-f", wav_path, "--language", "auto"]

        # Añadimos opciones según lo que pida el usuario
        if not with_timestamps:
            cmd.append("--no-timestamps") # Si no quiere tiempos, intentamos ocultarlos (whisper siempre los saca, luego los limpiamos)

        # --- AQUÍ ESTÁ LA MAGIA DE LA DIARIZACIÓN ---
        if diarize:
            cmd.append("--diarize")
        # --------------------------------------------

        current_process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)

        # Patrón para detectar tiempos y mover la barra
        timestamp_pattern = re.compile(r"\[(\d{2}):(\d{2}):(\d{2}\.\d{3})")

        while True:
            if is_cancelled: break

            line = current_process.stdout.readline()
            if not line and current_process.poll() is not None: break

            if line:
                # Actualizar barra de progreso
                match = timestamp_pattern.search(line)
                if match and total_duration > 0:
                    h, m, s = map(float, match.groups())
                    current_seconds = h * 3600 + m * 60 + s
                    callback_progress(current_seconds / total_duration)

                # Filtrar basura del sistema y enviar texto
                if "system_info" not in line and "main:" not in line:
                    callback_text(line)

        if os.path.exists(TEMP_WAV): os.remove(TEMP_WAV)
        current_process = None

        if is_cancelled:
            callback_text("\n[INFO] Transcripción cancelada por el usuario.")
            callback_progress(0)
        else:
            callback_progress(1.0)
            callback_text("\n\n[LISTO] Transcripción finalizada.")

    except Exception as e:
        callback_text(f"\n[ERROR]: {str(e)}")
